//
//  BarcodeSearchViewController.swift
//  BarcodeDemoApp
//
//  Created by Adarsh Roy Choudhary on 06/02/21.
//  Copyright © 2021 Fpts. All rights reserved.
//

import UIKit
import AVFoundation

class BarcodeSearchViewController: UIViewController  {

    @IBOutlet var messageLabel:UILabel!
    @IBOutlet var topbar: UIView!
    @IBOutlet var messageLabelHeight: NSLayoutConstraint!
    @IBOutlet var barCodeDetectedView: UIView!
    @IBOutlet var buttonProceed: UIButton!
    @IBOutlet var productNameLabel: UILabel!
    @IBOutlet var barCodeLabel: UILabel!
    
    var blockDismiss:((String)->())?
    var blockSuccess:((String)->())?
    
    var captureSession = AVCaptureSession()
    
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var barCodeFrameView: UIView?
    
    private var isAnimating: Bool = false
    
    private let supportedCodeTypes = [AVMetadataObject.ObjectType.upce,
                                      AVMetadataObject.ObjectType.code39,
                                      AVMetadataObject.ObjectType.code39Mod43,
                                      AVMetadataObject.ObjectType.code93,
                                      AVMetadataObject.ObjectType.code128,
                                      AVMetadataObject.ObjectType.ean8,
                                      AVMetadataObject.ObjectType.ean13,
                                      AVMetadataObject.ObjectType.aztec,
                                      AVMetadataObject.ObjectType.pdf417,
                                      AVMetadataObject.ObjectType.itf14,
                                      AVMetadataObject.ObjectType.dataMatrix,
                                      AVMetadataObject.ObjectType.interleaved2of5,
                                      AVMetadataObject.ObjectType.qr]
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.askPermission()
    }
 
    
    func setupUI() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [unowned self] in
            self.hideBarCodeDetectedView()
            self.barCodeDetectedView.updateConstraints()
            self.buttonProceed.layer.borderColor = UIColor.black.cgColor
        }
    }
    //MARK: - Animation
    private func presentAnimationToView() {
        if !isAnimating {
            isAnimating = true
            self.barCodeDetectedView.transform = CGAffineTransform(translationX: 0, y: self.view.frame.height)
            barCodeDetectedView.isHidden = false
            UIView.animate(withDuration: 0.25) {
                self.barCodeDetectedView.transform = CGAffineTransform.identity
            }
        }
    }
    
    func showBarCodeDetectedView(withBarcode barcode: String) {
        barCodeLabel.text = barcode
        presentAnimationToView()
        messageLabelHeight.constant = 0
    }
    
    func hideBarCodeDetectedView() {
        barCodeDetectedView.isHidden = true
        messageLabelHeight.constant = 40
    }
    
    @IBAction func buttonProceedAction(_ sender: UIButton) {
        if let text =  barCodeLabel.text {
            self.dismissAnimate {
                self.blockSuccess?(text)
            }
        }
    }
    
    func askPermission() {
        let cameraMediaType = AVMediaType.video
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: cameraMediaType)
        
        switch cameraAuthorizationStatus {
        case .authorized:
            self.startVideoCapture()
            break
        case .restricted,.denied,.notDetermined:
            AVCaptureDevice.requestAccess(for: AVMediaType.video) { granted in
                if !granted {
                    let alert = UIAlertController.init(title: "Allow the app to access your camera.", message: "The App needs access to your camera to scan the barcode/QR-code.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Allow access", style: .default) { action in
                        if let url = NSURL(string:UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                        }
                    })
                    alert.addAction(UIAlertAction(title: "Not now", style: .default) { action in
                         self.dismissAnimate {
                            self.blockDismiss?("access-denied")
                        }
                    })
                    DispatchQueue.main.async {
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                else{
                    self.startVideoCapture()
                }
            }
        default: break
        }
    }
    
    
    internal class func showBarCodeViewController(sourceViewController: UIViewController, success:@escaping (String)->(), dismiss:@escaping (String)->()) {
        
        let viewController = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: String(describing: BarcodeSearchViewController.self)) as! BarcodeSearchViewController
        viewController.blockSuccess = success
        viewController.blockDismiss = dismiss
        viewController.presentSpeechToTextViewControllerWith(sourceController: sourceViewController)
    }
    
    func presentSpeechToTextViewControllerWith(sourceController: UIViewController)  {
        sourceController.present(self, animated: true, completion: nil)
    }
    
    func createFrame() -> CAShapeLayer {
        let height: CGFloat = (self.videoPreviewLayer?.frame.size.height)!
        let width: CGFloat = (self.videoPreviewLayer?.frame.size.width)!
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 1, y: 25))
        path.addLine(to: CGPoint(x: 1, y: 1))
        path.addLine(to: CGPoint(x: 25, y: 1))
        path.move(to: CGPoint(x: width - 30, y: 1))
        path.addLine(to: CGPoint(x: width - 5, y: 1))
        path.addLine(to: CGPoint(x: width - 5, y: 25))
        path.move(to: CGPoint(x: 1, y: height - 30))
        path.addLine(to: CGPoint(x: 1, y: height - 5))
        path.addLine(to: CGPoint(x: 25, y: height - 5))
        path.move(to: CGPoint(x: width - 30, y: height - 5))
        path.addLine(to: CGPoint(x: width - 5, y: height - 5))
        path.addLine(to: CGPoint(x: width - 5, y: height - 30))
        let shape = CAShapeLayer()
        shape.path = path.cgPath
        shape.strokeColor = UIColor.white.cgColor
        shape.lineWidth = 5
        shape.fillColor = UIColor.clear.cgColor
        return shape
    }
    
    func startVideoCapture(){
        // Get an instance of the AVCaptureDevice class to initialize a device object and provide the video as the media type parameter.
        if let captureDevice = AVCaptureDevice.default(for: AVMediaType.video) {
        
        do {
            // Get an instance of the AVCaptureDeviceInput class using the previous device object.
            let input = try AVCaptureDeviceInput(device: captureDevice)
            
            // Initialize the captureSession object.
            captureSession = AVCaptureSession()
            
            // Set the input device on the capture session.
            captureSession.addInput(input)
            
            // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession.addOutput(captureMetadataOutput)
            
            // Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = captureMetadataOutput.availableMetadataObjectTypes
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
            DispatchQueue.main.async {
                self.videoPreviewLayer?.frame = CGRect(x: self.view.frame.origin.x, y: self.view.frame.size.height/2.5, width: self.view.frame.size.width, height: self.view.frame.size.height/2.5)
                
                self.videoPreviewLayer?.position = CGPoint(x:self.view.bounds.midX,y: self.view.bounds.midY)
                self.view.layer.addSublayer(self.videoPreviewLayer!)
                self.view.clipsToBounds = true
                self.videoPreviewLayer!.addSublayer(self.createFrame())
            }
            // Start video capture.
            captureSession.startRunning()

        } catch {
            // If any error occurs, simply print it out and don't continue any more.
            print(error)
            return
        }
    }
    }
    
    //MARK: - Animation
    
    fileprivate func dismissAnimate(completion:@escaping ()->()) {
        self.dismiss(animated: true) {
            completion()
        }

    }

    @IBAction func dismissAction(_ sender: UIButton) {
        self.dismissAnimate {
            self.blockDismiss?("window-closed")
            /*
            let arrNames = AppUtils.sharedInstance.inventoryItems.map { $0.itemName }
            self.blockDismiss?(arrNames[i])
            i = i + 1
            if i == arrNames.count {
                i = 0
            }
            */
        }
    }
    
}
//var i = 0


extension BarcodeSearchViewController: AVCaptureMetadataOutputObjectsDelegate {
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects.count == 0 {
            barCodeFrameView?.frame = CGRect.zero
            //messageLabel.text = "No QR code is detected"
            return
        }
        
        
        // Get the metadata object.
        guard let metadataObj = metadataObjects[0] as? AVMetadataMachineReadableCodeObject else{
            // Display some sort of error message or handle it
            return
        }
        
        if supportedCodeTypes.contains(metadataObj.type) {
            // If the found metadata is equal to the QR code metadata (or barcode) then update the status label's text and set the bounds
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            barCodeFrameView?.frame = barCodeObject!.bounds
            
            if metadataObj.stringValue != nil {
                showBarCodeDetectedView(withBarcode: metadataObj.stringValue!)
            }
        }
    }
    
}
