//
//  ItemCell.swift
//  BarcodeDemoApp
//
//  Created by Adarsh Roy Choudhary on 06/02/21.
//  Copyright © 2021 Fpts. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell {
    @IBOutlet weak var labelItemName: UILabel!
    @IBOutlet weak var labelItemPrice: UILabel!
    @IBOutlet weak var imageViewItem: UIImageView!
    
    var item: Item! {
        didSet {
            labelItemName.text = item.itemName
            labelItemPrice.text = "Rs " + item.itemPrice
            imageViewItem.image = UIImage(named: item.itemImageName)
        }
    }
}
