//
//  AppUtils.swift
//  BarcodeDemoApp
//
//  Created by Adarsh Roy Choudhary on 06/02/21.
//  Copyright © 2021 Fpts. All rights reserved.
//

import UIKit

let INVENTORY_STRING = "Apple,apple-img,120.00|Mango,mango-img,250.00|Maggi,maggi-img,15.00|Chocolate,chocolate-img,500.00|Chips,chips-img,10.00|Deodrant,deodrant-img,150.00|Sanitizer,sanitizer-img,180.00"

class AppUtils: NSObject {
    static let sharedInstance = AppUtils()
    private override init() { super.init() }

    var inventoryItems: [Item] = []

    func storeAllInventoryItems() {
        inventoryItems = []
        for strItem in INVENTORY_STRING.components(separatedBy: "|") {
            let attributes = strItem.components(separatedBy: ",")
            let item = Item(itemName: attributes[0], itemImageName: attributes[1], itemPrice: attributes[2])
            inventoryItems.append(item)
        }
    }
}
