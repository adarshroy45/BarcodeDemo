//
//  CartViewModel.swift
//  BarcodeDemoApp
//
//  Created by Adarsh Roy Choudhary on 06/02/21.
//  Copyright © 2021 Fpts. All rights reserved.
//

import Foundation
import UIKit

class CartViewModel {
    var items: [Item] = []

    func addItemToCart(withName itemName: String, completion: (Bool)->()) {
        let item = AppUtils.sharedInstance.inventoryItems.filter { $0.itemName == itemName}.first
        guard let itemNew = item else {
            completion(false)
            return
        }
        items.insert(itemNew, at: 0)
        completion(true)
    }
}


extension CartViewModel { //TableView Datasource
    func tableView(numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ItemCell.self), for: indexPath) as! ItemCell
        cell.item = items[indexPath.row]
        return cell
    }
}
