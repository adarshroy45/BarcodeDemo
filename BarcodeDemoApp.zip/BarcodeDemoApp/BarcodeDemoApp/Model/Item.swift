//
//  Item.swift
//  BarcodeDemoApp
//
//  Created by Adarsh Roy Choudhary on 06/02/21.
//  Copyright © 2021 Fpts. All rights reserved.
//

import Foundation

struct Item {
    var itemName: String
    var itemImageName: String
    var itemPrice: String
}
