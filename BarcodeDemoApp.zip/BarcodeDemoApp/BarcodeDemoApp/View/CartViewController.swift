//
//  CartViewController.swift
//  BarcodeDemoApp
//
//  Created by Adarsh Roy Choudhary on 06/02/21.
//  Copyright © 2021 Fpts. All rights reserved.
//

import UIKit

///INTRUCTIONS

///Please Generate Barcodes with Product names with item names as mentioned in AppUtils.swift file line no.11
///for eg., the decoded string should be anything within this list [Apple, Mango, Maggi, Chocolate, Chips, Deodrant, Sanitizer]
///Tap On Scan on Top-left corner of screen
///On Tapping Proceed button, your item will be added in the Cart
///
///

class CartViewController: UIViewController {

    @IBOutlet weak var tableViewItem: UITableView!
    @IBOutlet weak var labelNoItems: UILabel!

    let viewModel = CartViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.reloadTable()
    }

    func reloadTable() {
        tableViewItem.reloadData()
        labelNoItems.isHidden = viewModel.items.count > 0
        tableViewItem.isHidden = !labelNoItems.isHidden
    }

    //MARK: - Actions
    @IBAction func scanBtnAction(_ sender: UIBarButtonItem) {
        ///Assuming barcode/Qr-code returns ItemName.
        BarcodeSearchViewController.showBarCodeViewController(sourceViewController: self, success: { [unowned self] (decodedString) in //It will be the itemName
            self.viewModel.addItemToCart(withName: decodedString) { [unowned self] isAdded in
                isAdded ? self.reloadTable() : ()
            }
        }, dismiss: { reason in
            self.viewModel.addItemToCart(withName: reason) { [unowned self] isAdded in
                isAdded ? self.reloadTable() : ()
            }
        })
    }

}

extension CartViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.tableView(numberOfRowsInSection: section)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return viewModel.tableView(tableView, cellForRowAt: indexPath)
    }
}

